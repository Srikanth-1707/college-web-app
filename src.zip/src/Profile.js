// Profile.js
import React from 'react';

function Profile() {
  return (
    <div>
      <h2>Profile Page</h2>
      {/* Add profile-related content here */}
    </div>
  );
}

export default Profile;
