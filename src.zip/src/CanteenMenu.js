// CanteenMenu.js
import React from 'react';

function CanteenMenu() {
  return (
    <div>
      <h2>Canteen Menu</h2>
      {/* Add canteen menu content here */}
    </div>
  );
}

export default CanteenMenu;
