// Timetable.js
import React from 'react';

function Timetable() {
  return (
    <div>
      <h2>Timetable</h2>
      {/* Add timetable content here */}
    </div>
  );
}

export default Timetable;
